namespace FacturXManager.Modules.Compliance.Application.Invoicing.DownloadInvoicePdf;

/// <summary>
/// Résultat du téléchargement : octets du PDF et nom de fichier suggéré.
/// </summary>
public sealed record DownloadInvoicePdfSummary(
    byte[] PdfBytes,
    string FileName);
