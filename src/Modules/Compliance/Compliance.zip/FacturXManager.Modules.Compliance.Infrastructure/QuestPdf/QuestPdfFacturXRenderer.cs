using System.Globalization;
using System.Text;
using FacturXManager.Common.Domain;
using FacturXManager.Modules.Compliance.Application.Abstractions;
using FacturXManager.Modules.Compliance.Domain.Invoicing;
using Microsoft.Extensions.Logging;
using PdfSharp.Pdf;
using PdfSharp.Pdf.Advanced;
using PdfSharp.Pdf.IO;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace FacturXManager.Modules.Compliance.Infrastructure.QuestPdf;

/// <summary>
/// Implémentation PDF/A-3b basée sur QuestPDF pour le rendu visuel
/// et PdfSharp 6.x pour l'embedding du XML CII (factur-x.xml) et des métadonnées XMP.
/// Produit un PDF avec les lignes d'articles détaillées.
/// </summary>
internal sealed class QuestPdfFacturXRenderer : IFacturXPdfA3BRenderer
{
    private readonly ILogger<QuestPdfFacturXRenderer> _logger;

    public QuestPdfFacturXRenderer(ILogger<QuestPdfFacturXRenderer> logger)
    {
        _logger = logger;
        QuestPDF.Settings.License = LicenseType.Community;
    }

    public async Task<Result<byte[]>> RenderAsync(
        FacturXRenderRequest request,
        CancellationToken cancellationToken = default)
    {
        try
        {
            // Génère le PDF visuel via QuestPDF
            byte[] pdfBytes = GenerateVisualPdf(request);

            // Ouvre le PDF avec PdfSharp pour embarquer le XML CII et les métadonnées XMP
            byte[] finalPdf = EmbedFacturXData(pdfBytes, request);

            return await Task.FromResult(Result.Success(finalPdf));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Échec du rendu QuestPDF/A-3b Factur-X pour la facture {InvoiceNumber}.", request.InvoiceNumber);
            return Result.Failure<byte[]>(InvoiceErrors.PdfRendererNotConfigured);
        }
    }

    /// <summary>
    /// Rendu enrichi avec les lignes de facture à partir d'un <see cref="QuestPdfRenderModel"/>.
    /// </summary>
    internal Result<byte[]> RenderWithLines(QuestPdfRenderModel model)
    {
        try
        {
            byte[] pdfBytes = GenerateDetailedPdf(model);

            var request = new FacturXRenderRequest(
                model.CrossIndustryInvoiceXml,
                model.EmbeddedFileName,
                model.InvoiceNumber,
                model.SellerName,
                model.BuyerName,
                model.IssueDate,
                model.CurrencyCode,
                model.TotalWithoutVat,
                model.TotalVat,
                model.TotalWithVat,
                model.Profile);

            byte[] finalPdf = EmbedFacturXData(pdfBytes, request);

            return Result.Success(finalPdf);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Échec du rendu QuestPDF détaillé pour la facture {InvoiceNumber}.", model.InvoiceNumber);
            return Result.Failure<byte[]>(InvoiceErrors.PdfRendererNotConfigured);
        }
    }

    private static byte[] GenerateVisualPdf(FacturXRenderRequest request)
    {
        var document = Document.Create(container => container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.MarginHorizontal(40);
                page.MarginVertical(50);
                page.DefaultTextStyle(x => x.FontSize(10));

                page.Header().Element(header => ComposeHeader(header, request));
                page.Content().Element(content => ComposeBasicContent(content, request));
                page.Footer().Element(ComposeFooter);
            }));

        return document.GeneratePdf();
    }

    private static byte[] GenerateDetailedPdf(QuestPdfRenderModel model)
    {
        var document = Document.Create(container => container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.MarginHorizontal(40);
                page.MarginVertical(50);
                page.DefaultTextStyle(x => x.FontSize(10));

                page.Header().Element(header => ComposeDetailedHeader(header, model));
                page.Content().Element(content => ComposeDetailedContent(content, model));
                page.Footer().Element(ComposeFooter);
            }));

        return document.GeneratePdf();
    }

    private static void ComposeHeader(IContainer container, FacturXRenderRequest request)
    {
        container.Row(row =>
        {
            row.RelativeItem().Column(col =>
            {
                col.Item().Text("FACTURE").FontSize(22).Bold();
                col.Item().Text($"N° {request.InvoiceNumber}").FontSize(12).SemiBold();
                col.Item().Text($"Date : {request.IssueDate.ToString("dd/MM/yyyy", CultureInfo.GetCultureInfo("fr-FR"))}");
            });

            row.RelativeItem().AlignRight().Column(col =>
            {
                col.Item().Text(request.SellerName).SemiBold();
                col.Item().PaddingTop(10).Text(request.BuyerName).Italic();
            });
        });
    }

    private static void ComposeDetailedHeader(IContainer container, QuestPdfRenderModel model)
    {
        container.Row(row => row.RelativeItem().Column(col =>
            {
                col.Item().Text("FACTURE").FontSize(22).Bold();
                col.Item().Text($"N° {model.InvoiceNumber}").FontSize(12).SemiBold();
                col.Item().Text($"Date d'émission : {model.IssueDate.ToString("dd/MM/yyyy", CultureInfo.GetCultureInfo("fr-FR"))}");
                col.Item().Text($"Devise : {model.CurrencyCode}");
            }));
    }

    private static void ComposeBasicContent(IContainer container, FacturXRenderRequest request)
    {
        container.PaddingVertical(20).Column(col =>
        {
            col.Item().LineHorizontal(1);
            col.Item().PaddingVertical(10).Row(row =>
            {
                row.RelativeItem().Text($"Montant HT : {FormatAmount(request.TotalWithoutVat, request.CurrencyCode)}");
                row.RelativeItem().Text($"TVA : {FormatAmount(request.TotalVat, request.CurrencyCode)}");
                row.RelativeItem().Text($"TTC : {FormatAmount(request.TotalWithVat, request.CurrencyCode)}").Bold();
            });
        });
    }

    private static void ComposeDetailedContent(IContainer container, QuestPdfRenderModel model)
    {
        container.PaddingVertical(10).Column(col =>
        {
            // Parties
            col.Item().PaddingBottom(15).Row(row =>
            {
                row.RelativeItem().Border(1).Padding(8).Column(sellerCol =>
                {
                    sellerCol.Item().Text("VENDEUR").FontSize(9).Bold();
                    sellerCol.Item().Text(model.SellerName).SemiBold();
                    sellerCol.Item().Text(model.SellerAddress).FontSize(9);
                    if (!string.IsNullOrWhiteSpace(model.SellerVatIdentifier))
                    {
                        sellerCol.Item().Text($"TVA : {model.SellerVatIdentifier}").FontSize(9);
                    }

                    if (!string.IsNullOrWhiteSpace(model.SellerLegalRegistrationId))
                    {
                        sellerCol.Item().Text($"SIREN : {model.SellerLegalRegistrationId}").FontSize(9);
                    }
                });

                row.ConstantItem(20);

                row.RelativeItem().Border(1).Padding(8).Column(buyerCol =>
                {
                    buyerCol.Item().Text("ACHETEUR").FontSize(9).Bold();
                    buyerCol.Item().Text(model.BuyerName).SemiBold();
                    buyerCol.Item().Text(model.BuyerAddress).FontSize(9);
                    if (!string.IsNullOrWhiteSpace(model.BuyerVatIdentifier))
                    {
                        buyerCol.Item().Text($"TVA : {model.BuyerVatIdentifier}").FontSize(9);
                    }

                    if (!string.IsNullOrWhiteSpace(model.BuyerLegalRegistrationId))
                    {
                        buyerCol.Item().Text($"SIREN : {model.BuyerLegalRegistrationId}").FontSize(9);
                    }
                });
            });

            // Tableau des lignes
            col.Item().PaddingBottom(10).Text("DÉTAIL DES PRESTATIONS").FontSize(11).Bold();

            col.Item().Table(table =>
            {
                table.ColumnsDefinition(columns =>
                {
                    columns.ConstantColumn(35);   // Réf
                    columns.RelativeColumn(3);    // Description
                    columns.ConstantColumn(50);   // Qté
                    columns.ConstantColumn(50);   // Unité
                    columns.ConstantColumn(70);   // PU HT
                    columns.ConstantColumn(45);   // TVA %
                    columns.ConstantColumn(75);   // Montant HT
                });

                // En-tête
                table.Header(header =>
                {
                    header.Cell().Background(Colors.Grey.Lighten3).Padding(4).Text("Réf").FontSize(9).Bold();
                    header.Cell().Background(Colors.Grey.Lighten3).Padding(4).Text("Description").FontSize(9).Bold();
                    header.Cell().Background(Colors.Grey.Lighten3).Padding(4).AlignRight().Text("Qté").FontSize(9).Bold();
                    header.Cell().Background(Colors.Grey.Lighten3).Padding(4).Text("Unité").FontSize(9).Bold();
                    header.Cell().Background(Colors.Grey.Lighten3).Padding(4).AlignRight().Text("PU HT").FontSize(9).Bold();
                    header.Cell().Background(Colors.Grey.Lighten3).Padding(4).AlignRight().Text("TVA %").FontSize(9).Bold();
                    header.Cell().Background(Colors.Grey.Lighten3).Padding(4).AlignRight().Text("Montant HT").FontSize(9).Bold();
                });

                // Lignes
                foreach (QuestPdfLineModel line in model.Lines)
                {
                    table.Cell().BorderBottom(0.5f).BorderColor(Colors.Grey.Lighten2).Padding(4).Text(line.Id).FontSize(9);
                    table.Cell().BorderBottom(0.5f).BorderColor(Colors.Grey.Lighten2).Padding(4).Text(line.Description).FontSize(9);
                    table.Cell().BorderBottom(0.5f).BorderColor(Colors.Grey.Lighten2).Padding(4).AlignRight().Text(line.Quantity.ToString("G", CultureInfo.GetCultureInfo("fr-FR"))).FontSize(9);
                    table.Cell().BorderBottom(0.5f).BorderColor(Colors.Grey.Lighten2).Padding(4).Text(line.UnitCode).FontSize(9);
                    table.Cell().BorderBottom(0.5f).BorderColor(Colors.Grey.Lighten2).Padding(4).AlignRight().Text(FormatAmount(line.UnitNetPrice, model.CurrencyCode)).FontSize(9);
                    table.Cell().BorderBottom(0.5f).BorderColor(Colors.Grey.Lighten2).Padding(4).AlignRight().Text($"{line.VatRate:G}%").FontSize(9);
                    table.Cell().BorderBottom(0.5f).BorderColor(Colors.Grey.Lighten2).Padding(4).AlignRight().Text(FormatAmount(line.NetAmount, model.CurrencyCode)).FontSize(9);
                }
            });

            col.Item().PaddingTop(15);

            // Ventilation TVA
            if (model.VatBreakdowns.Count > 0)
            {
                col.Item().PaddingBottom(5).Text("VENTILATION TVA").FontSize(10).Bold();
                col.Item().Table(table =>
                {
                    table.ColumnsDefinition(columns =>
                    {
                        columns.RelativeColumn();  // Catégorie
                        columns.RelativeColumn();  // Taux
                        columns.RelativeColumn();  // Base HT
                        columns.RelativeColumn();  // Montant TVA
                    });

                    table.Header(header =>
                    {
                        header.Cell().Background(Colors.Grey.Lighten3).Padding(4).Text("Catégorie").FontSize(9).Bold();
                        header.Cell().Background(Colors.Grey.Lighten3).Padding(4).AlignRight().Text("Taux").FontSize(9).Bold();
                        header.Cell().Background(Colors.Grey.Lighten3).Padding(4).AlignRight().Text("Base HT").FontSize(9).Bold();
                        header.Cell().Background(Colors.Grey.Lighten3).Padding(4).AlignRight().Text("Montant TVA").FontSize(9).Bold();
                    });

                    foreach (QuestPdfVatBreakdownModel vat in model.VatBreakdowns)
                    {
                        table.Cell().Padding(4).Text(vat.Category).FontSize(9);
                        table.Cell().Padding(4).AlignRight().Text($"{vat.Rate:G}%").FontSize(9);
                        table.Cell().Padding(4).AlignRight().Text(FormatAmount(vat.BasisAmount, model.CurrencyCode)).FontSize(9);
                        table.Cell().Padding(4).AlignRight().Text(FormatAmount(vat.TaxAmount, model.CurrencyCode)).FontSize(9);
                    }
                });

                col.Item().PaddingTop(10);
            }

            // Totaux
            col.Item().AlignRight().Width(250).Table(table =>
            {
                table.ColumnsDefinition(columns =>
                {
                    columns.RelativeColumn();
                    columns.ConstantColumn(100);
                });

                table.Cell().Padding(4).Text("Total HT").FontSize(10);
                table.Cell().Padding(4).AlignRight().Text(FormatAmount(model.TotalWithoutVat, model.CurrencyCode)).FontSize(10);

                table.Cell().Padding(4).Text("Total TVA").FontSize(10);
                table.Cell().Padding(4).AlignRight().Text(FormatAmount(model.TotalVat, model.CurrencyCode)).FontSize(10);

                table.Cell().Background(Colors.Grey.Lighten3).Padding(4).Text("Total TTC").FontSize(11).Bold();
                table.Cell().Background(Colors.Grey.Lighten3).Padding(4).AlignRight().Text(FormatAmount(model.TotalWithVat, model.CurrencyCode)).FontSize(11).Bold();

                table.Cell().Padding(4).Text("Net à payer").FontSize(10).SemiBold();
                table.Cell().Padding(4).AlignRight().Text(FormatAmount(model.AmountDue, model.CurrencyCode)).FontSize(10).SemiBold();
            });

            // Modalités de paiement
            col.Item().PaddingTop(15).Column(payCol =>
            {
                payCol.Item().Text("MODALITÉS DE PAIEMENT").FontSize(10).Bold();
                if (model.PaymentDueDate.HasValue)
                {
                    payCol.Item().Text($"Échéance : {model.PaymentDueDate.Value.ToString("dd/MM/yyyy", CultureInfo.GetCultureInfo("fr-FR"))}").FontSize(9);
                }

                if (!string.IsNullOrWhiteSpace(model.PaymentIban))
                {
                    payCol.Item().Text($"IBAN : {model.PaymentIban}").FontSize(9);
                }
            });
        });
    }

    private static void ComposeFooter(IContainer container)
    {
        container.AlignCenter().Text(text =>
        {
            text.DefaultTextStyle(x => x.FontSize(8).FontColor(Colors.Grey.Medium));
            text.Span("Factur-X EN16931 — facture électronique conforme à la réforme française | Page ");
            text.CurrentPageNumber();
            text.Span(" / ");
            text.TotalPages();
        });
    }

    private static string FormatAmount(decimal amount, string currency) =>
        string.Format(CultureInfo.GetCultureInfo("fr-FR"), "{0:N2} {1}", amount, currency);

    private static byte[] EmbedFacturXData(byte[] pdfBytes, FacturXRenderRequest request)
    {
        using var inputStream = new MemoryStream(pdfBytes);
        using PdfDocument document = PdfReader.Open(inputStream, PdfDocumentOpenMode.Modify);

        byte[] xmlBytes = Encoding.UTF8.GetBytes(request.CrossIndustryInvoiceXml);
        AttachFacturXXml(document, request.EmbeddedFileName, xmlBytes);
        AttachXmpMetadata(document, request);

        using var outputStream = new MemoryStream();
        document.Save(outputStream, closeStream: false);
        return outputStream.ToArray();
    }

    private static void AttachFacturXXml(PdfDocument document, string fileName, byte[] xmlBytes)
    {
        var embeddedStream = new PdfDictionary(document);
        embeddedStream.Elements.SetName("/Type", "/EmbeddedFile");
        embeddedStream.Elements.SetString("/Subtype", "application/xml");
        embeddedStream.CreateStream(xmlBytes);

        var paramsDict = new PdfDictionary(document);
        paramsDict.Elements.SetInteger("/Size", xmlBytes.Length);
        paramsDict.Elements.SetDateTime("/ModDate", DateTime.UtcNow);
        embeddedStream.Elements["/Params"] = paramsDict;

        document.Internals.AddObject(embeddedStream);

        var efDict = new PdfDictionary(document);
        efDict.Elements["/F"] = embeddedStream.Reference;
        efDict.Elements["/UF"] = embeddedStream.Reference;

        var fileSpec = new PdfDictionary(document);
        fileSpec.Elements.SetName("/Type", "/Filespec");
        fileSpec.Elements.SetString("/F", fileName);
        fileSpec.Elements.SetString("/UF", fileName);
        fileSpec.Elements.SetString("/Desc", "Factur-X invoice data");
        fileSpec.Elements.SetName("/AFRelationship", "/Data");
        fileSpec.Elements["/EF"] = efDict;
        document.Internals.AddObject(fileSpec);

        PdfCatalog catalog = document.Internals.Catalog;
        PdfDictionary namesDict = catalog.Elements.GetDictionary("/Names") ?? new PdfDictionary(document);
        var embeddedFilesDict = new PdfDictionary(document);
        var namesArray = new PdfArray(document);
        namesArray.Elements.Add(new PdfString(fileName));
        namesArray.Elements.Add(fileSpec.Reference!);
        embeddedFilesDict.Elements["/Names"] = namesArray;
        namesDict.Elements["/EmbeddedFiles"] = embeddedFilesDict;
        catalog.Elements["/Names"] = namesDict;

        var afArray = new PdfArray(document);
        afArray.Elements.Add(fileSpec.Reference!);
        catalog.Elements["/AF"] = afArray;
    }

    private static void AttachXmpMetadata(PdfDocument document, FacturXRenderRequest request)
    {
        string conformanceLevel = request.Profile switch
        {
            FacturXProfile.Minimum => "MINIMUM",
            FacturXProfile.BasicWl => "BASIC WL",
            FacturXProfile.Basic => "BASIC",
            FacturXProfile.Extended => "EXTENDED",
            _ => "EN 16931"
        };

        string xmp = BuildXmpPacket(request, conformanceLevel);
        byte[] xmpBytes = Encoding.UTF8.GetBytes(xmp);

        var metadataDict = new PdfDictionary(document);
        metadataDict.Elements.SetName("/Type", "/Metadata");
        metadataDict.Elements.SetName("/Subtype", "/XML");
        metadataDict.CreateStream(xmpBytes);

        document.Internals.AddObject(metadataDict);
        document.Internals.Catalog.Elements["/Metadata"] = metadataDict.Reference;
    }

    private static string BuildXmpPacket(FacturXRenderRequest request, string conformanceLevel)
    {
        string creationDate = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ", CultureInfo.InvariantCulture);
        return $"""
            <?xpacket begin="﻿" id="W5M0MpCehiHzreSzNTczkc9d"?>
            <x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="FacturXManager">
              <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
                <rdf:Description rdf:about=""
                    xmlns:pdfaid="http://www.aiim.org/pdfa/ns/id/">
                  <pdfaid:part>3</pdfaid:part>
                  <pdfaid:conformance>B</pdfaid:conformance>
                </rdf:Description>
                <rdf:Description rdf:about=""
                    xmlns:dc="http://purl.org/dc/elements/1.1/">
                  <dc:title><rdf:Alt><rdf:li xml:lang="x-default">Facture {Escape(request.InvoiceNumber)}</rdf:li></rdf:Alt></dc:title>
                  <dc:creator><rdf:Seq><rdf:li>{Escape(request.SellerName)}</rdf:li></rdf:Seq></dc:creator>
                </rdf:Description>
                <rdf:Description rdf:about=""
                    xmlns:xmp="http://ns.adobe.com/xap/1.0/">
                  <xmp:CreatorTool>FacturXManager</xmp:CreatorTool>
                  <xmp:CreateDate>{creationDate}</xmp:CreateDate>
                  <xmp:ModifyDate>{creationDate}</xmp:ModifyDate>
                </rdf:Description>
                <rdf:Description rdf:about=""
                    xmlns:fx="urn:factur-x:pdfa:CrossIndustryDocument:invoice:1p0#">
                  <fx:DocumentType>INVOICE</fx:DocumentType>
                  <fx:DocumentFileName>{Escape(request.EmbeddedFileName)}</fx:DocumentFileName>
                  <fx:Version>1.0</fx:Version>
                  <fx:ConformanceLevel>{conformanceLevel}</fx:ConformanceLevel>
                </rdf:Description>
              </rdf:RDF>
            </x:xmpmeta>
            <?xpacket end="w"?>
            """;
    }

    private static string Escape(string value) =>
        value
            .Replace("&", "&amp;", StringComparison.Ordinal)
            .Replace("<", "&lt;", StringComparison.Ordinal)
            .Replace(">", "&gt;", StringComparison.Ordinal);
}
