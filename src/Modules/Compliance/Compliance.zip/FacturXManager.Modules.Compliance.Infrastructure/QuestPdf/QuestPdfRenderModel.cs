using FacturXManager.Modules.Compliance.Domain.Invoicing;

namespace FacturXManager.Modules.Compliance.Infrastructure.QuestPdf;

/// <summary>
/// Données de rendu enrichies pour QuestPDF, incluant les lignes de facture
/// et les ventilations TVA absentes du <see cref="Application.Abstractions.FacturXRenderRequest"/> de base.
/// </summary>
internal sealed record QuestPdfRenderModel(
    string CrossIndustryInvoiceXml,
    string EmbeddedFileName,
    string InvoiceNumber,
    string SellerName,
    string SellerAddress,
    string? SellerVatIdentifier,
    string? SellerLegalRegistrationId,
    string BuyerName,
    string BuyerAddress,
    string? BuyerVatIdentifier,
    string? BuyerLegalRegistrationId,
    DateOnly IssueDate,
    string CurrencyCode,
    decimal TotalWithoutVat,
    decimal TotalVat,
    decimal TotalWithVat,
    decimal AmountDue,
    string PaymentMeansCode,
    string? PaymentIban,
    DateOnly? PaymentDueDate,
    IReadOnlyList<QuestPdfLineModel> Lines,
    IReadOnlyList<QuestPdfVatBreakdownModel> VatBreakdowns,
    FacturXProfile Profile = FacturXProfile.En16931)
{
    /// <summary>
    /// Construit le modèle de rendu à partir d'un agrégat <see cref="Invoice"/> et du XML CII déjà généré.
    /// </summary>
    public static QuestPdfRenderModel FromInvoice(Invoice invoice, string crossIndustryInvoiceXml) =>
        new(
            CrossIndustryInvoiceXml: crossIndustryInvoiceXml,
            EmbeddedFileName: "factur-x.xml",
            InvoiceNumber: invoice.Number,
            SellerName: invoice.Seller.Name,
            SellerAddress: FormatAddress(invoice.Seller.Address),
            SellerVatIdentifier: invoice.Seller.VatIdentifier,
            SellerLegalRegistrationId: invoice.Seller.LegalRegistrationId,
            BuyerName: invoice.Buyer.Name,
            BuyerAddress: FormatAddress(invoice.Buyer.Address),
            BuyerVatIdentifier: invoice.Buyer.VatIdentifier,
            BuyerLegalRegistrationId: invoice.Buyer.LegalRegistrationId,
            IssueDate: invoice.IssueDate,
            CurrencyCode: invoice.CurrencyCode,
            TotalWithoutVat: invoice.TotalWithoutVat,
            TotalVat: invoice.TotalVat,
            TotalWithVat: invoice.TotalWithVat,
            AmountDue: invoice.AmountDue,
            PaymentMeansCode: invoice.Payment.MeansCode,
            PaymentIban: invoice.Payment.Iban,
            PaymentDueDate: invoice.Payment.DueDate,
            Lines: invoice.Lines.Select(l => new QuestPdfLineModel(
                l.Id, l.Description, l.Quantity, l.UnitCode, l.UnitNetPrice, l.VatRate, l.NetAmount)).ToList(),
            VatBreakdowns: invoice.VatBreakdowns.Select(v => new QuestPdfVatBreakdownModel(
                v.Category.ToString(), v.Rate, v.BasisAmount, v.TaxAmount)).ToList(),
            Profile: invoice.Profile);

    private static string FormatAddress(PostalAddress address) =>
        string.IsNullOrWhiteSpace(address.Line2)
            ? $"{address.Line1}, {address.PostalCode} {address.City}, {address.CountryCode}"
            : $"{address.Line1}, {address.Line2}, {address.PostalCode} {address.City}, {address.CountryCode}";
}

internal sealed record QuestPdfLineModel(
    string Id,
    string Description,
    decimal Quantity,
    string UnitCode,
    decimal UnitNetPrice,
    decimal VatRate,
    decimal NetAmount);

internal sealed record QuestPdfVatBreakdownModel(
    string Category,
    decimal Rate,
    decimal BasisAmount,
    decimal TaxAmount);
