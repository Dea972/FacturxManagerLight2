using s2industries.ZUGFeRD;
using FacturXManager.Modules.Compliance.Application.Abstractions;
using FacturXManager.Modules.Compliance.Domain.Invoicing;

namespace FacturXManager.Modules.Compliance.Infrastructure.Zugferd;

/// <summary>
/// Génère le XML Cross Industry Invoice (CII) conforme EN16931 via la bibliothèque ZUGFeRD-csharp.
/// Implémentation alternative à <see cref="Invoicing.CrossIndustryInvoiceWriter"/> (System.Xml.Linq).
/// </summary>
internal sealed class ZugferdCrossIndustryInvoiceWriter : ICrossIndustryInvoiceWriter
{
    public string Write(Invoice invoice)
    {
        var descriptor = InvoiceDescriptor.CreateInvoice(
            invoice.Number,
            invoice.IssueDate.ToDateTime(TimeOnly.MinValue),
            MapCurrencyCode(invoice.CurrencyCode));

        descriptor.Type = InvoiceType.Invoice;
        descriptor.ReferenceOrderNo = invoice.PurchaseOrderReference ?? string.Empty;

        if (!string.IsNullOrWhiteSpace(invoice.BuyerReference))
        {
            descriptor.SetBuyerOrderReferenceDocument(invoice.BuyerReference);
        }

        // Vendeur (BG-4)
        descriptor.SetSeller(
            invoice.Seller.Name,
            invoice.Seller.Address.PostalCode,
            invoice.Seller.Address.City,
            invoice.Seller.Address.Line1,
            MapCountryCode(invoice.Seller.Address.CountryCode));

        if (!string.IsNullOrWhiteSpace(invoice.Seller.VatIdentifier))
        {
            descriptor.AddSellerTaxRegistration(invoice.Seller.VatIdentifier, TaxRegistrationSchemeID.VA);
        }

        if (!string.IsNullOrWhiteSpace(invoice.Seller.LegalRegistrationId))
        {
            descriptor.AddSellerTaxRegistration(invoice.Seller.LegalRegistrationId, TaxRegistrationSchemeID.FC);
        }

        // Acheteur (BG-7)
        descriptor.SetBuyer(
            invoice.Buyer.Name,
            invoice.Buyer.Address.PostalCode,
            invoice.Buyer.Address.City,
            invoice.Buyer.Address.Line1,
            MapCountryCode(invoice.Buyer.Address.CountryCode));

        if (!string.IsNullOrWhiteSpace(invoice.Buyer.VatIdentifier))
        {
            descriptor.AddBuyerTaxRegistration(invoice.Buyer.VatIdentifier, TaxRegistrationSchemeID.VA);
        }

        if (!string.IsNullOrWhiteSpace(invoice.Buyer.LegalRegistrationId))
        {
            descriptor.AddBuyerTaxRegistration(invoice.Buyer.LegalRegistrationId, TaxRegistrationSchemeID.FC);
        }

        // Modalités de paiement (BG-16)
        descriptor.SetPaymentMeans(
            MapPaymentMeansCode(invoice.Payment.MeansCode),
            string.Empty);

        if (invoice.Payment.DueDate.HasValue)
        {
            descriptor.SetPaymentMeans(
                MapPaymentMeansCode(invoice.Payment.MeansCode),
                string.Empty);
            descriptor.AddTradePaymentTerms(
                string.Empty,
                invoice.Payment.DueDate.Value.ToDateTime(TimeOnly.MinValue));
        }

        if (!string.IsNullOrWhiteSpace(invoice.Payment.Iban))
        {
            descriptor.SetPaymentMeansSepaDirectDebit(
                string.Empty,
                invoice.Payment.Iban);
        }

        // Lignes de facture (BG-25)
        foreach (InvoiceLine line in invoice.Lines)
        {
            descriptor.AddTradeLineItem(
                lineID: line.Id,
                name: line.Description,
                billedQuantity: line.Quantity,
                unitCode: MapQuantityCode(line.UnitCode),
                netUnitPrice: line.UnitNetPrice,
                categoryCode: MapTaxCategoryCode(line.VatCategory),
                taxPercent: line.VatRate,
                taxType: TaxTypes.VAT);
        }

        // Ventilation TVA (BG-23)
        foreach (VatBreakdown breakdown in invoice.VatBreakdowns)
        {
            descriptor.AddApplicableTradeTax(
                breakdown.BasisAmount,
                breakdown.Rate,
                breakdown.TaxAmount,
                TaxTypes.VAT,
                MapTaxCategoryCode(breakdown.Category));
        }

        // Totaux
        descriptor.SetTotals(
            lineTotalAmount: invoice.TotalWithoutVat,
            taxBasisAmount: invoice.TotalWithoutVat,
            taxTotalAmount: invoice.TotalVat,
            grandTotalAmount: invoice.TotalWithVat,
            duePayableAmount: invoice.AmountDue);

        using var stream = new MemoryStream();
        descriptor.Save(stream, ZUGFeRDVersion.Version23, MapProfile(invoice.Profile));
        stream.Position = 0;

        using var reader = new StreamReader(stream, System.Text.Encoding.UTF8);
        return reader.ReadToEnd();
    }

    private static CurrencyCodes MapCurrencyCode(string code) =>
        Enum.TryParse<CurrencyCodes>(code, ignoreCase: true, out CurrencyCodes result)
            ? result
            : CurrencyCodes.EUR;

    private static Profile MapProfile(FacturXProfile profile) => profile switch
    {
        FacturXProfile.Minimum => Profile.Minimum,
        FacturXProfile.BasicWl => Profile.BasicWL,
        FacturXProfile.Basic => Profile.Basic,
        FacturXProfile.En16931 => Profile.Comfort,
        FacturXProfile.Extended => Profile.Extended,
        _ => Profile.Comfort
    };

    private static CountryCodes MapCountryCode(string countryCode) =>
        Enum.TryParse<CountryCodes>(countryCode, ignoreCase: true, out CountryCodes result)
            ? result
            : CountryCodes.FR;

    private static PaymentMeansTypeCodes MapPaymentMeansCode(string code) =>
        int.TryParse(code, out int numericCode)
            ? (PaymentMeansTypeCodes)numericCode
            : PaymentMeansTypeCodes.SEPACreditTransfer;

    private static QuantityCodes MapQuantityCode(string unitCode) =>
        Enum.TryParse<QuantityCodes>(unitCode, ignoreCase: true, out QuantityCodes result)
            ? result
            : QuantityCodes.C62;

    private static TaxCategoryCodes MapTaxCategoryCode(VatCategory category) => category switch
    {
        VatCategory.Standard => TaxCategoryCodes.S,
        VatCategory.ZeroRated => TaxCategoryCodes.Z,
        VatCategory.Exempt => TaxCategoryCodes.E,
        _ => TaxCategoryCodes.S
    };
}
